# 1-Unzip FlightSearchProject
# 2-Uzip FlightSearchWebsite (published folder of the website)
# 3-Restore the Flights.bak file in sql
# 4-Use IIS to create new application and set path to the FlightSearchWebsite unzipped folder.
# 5-Inside FlightSearchWebsite folder edit the webconfig file and set data source to server where Flights.bak is restored on sql server and insert the intial catalogue
# to the database name.
# 6- In IIS right click on the FlightSearch application and browse.
# Done. The flight search engine should be loaded in the browser.
